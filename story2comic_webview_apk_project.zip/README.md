# Story2ComicWebView (폰만으로 APK 만들기)

이 프로젝트는 Story2Comic WebApp+를 WebView로 감싼 Android APK입니다.
- file input SAF로 열어 content:// 파일 선택 지원
- assets/www/index.html 로드

## 폰만으로 APK 만들기 (PC 없이)
1) GitHub 앱(또는 브라우저)에서 새 Repo 생성
2) 이 ZIP 내용을 Repo에 업로드/푸시
3) Repo → Actions → 'Build APK' → Run workflow
4) 완료 후 Artifacts에서 app-debug.apk 다운로드 → 폰에 설치

설치 시 '알 수 없는 앱 설치' 허용 필요.
